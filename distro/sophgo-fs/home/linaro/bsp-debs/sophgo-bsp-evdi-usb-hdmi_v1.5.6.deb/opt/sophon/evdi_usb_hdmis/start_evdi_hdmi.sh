#!/bin/bash

is_kylinos=$(cat /etc/os-release | grep kylinos |wc -l)

systemctl stop SophonHDMI
systemctl disable SophonHDMI
systemctl stop SophonHDMIStatus
systemctl disable SophonHDMIStatus
systemctl stop display-manager

export EVDI_HDMI_PWD="$(dirname "$(readlink -f "$0")")"
if ! modprobe evdi; then
        echo 'evdi kernel module not found' 1>&2
        exit 1
fi
sleep 3
pushd ${EVDI_HDMI_PWD}
chmod +x ./*
popd

USB_HDMI_CHIP=""
if [[ "$(lsusb | grep -i "1D5C:2000" | wc -l)" != 0 ]]; then
    USB_HDMI_CHIP="FL2000"
elif [[ "$(lsusb | grep -i "345F:9132" | wc -l)" != 0 ]]; then
    USB_HDMI_CHIP="MS9132"
elif [[ "$(lsusb | grep -i "345F:9133" | wc -l)" != 0 ]]; then
    USB_HDMI_CHIP="MS9132"
fi

if [[ "$USB_HDMI_CHIP" != "" ]]; then
    # disable auto sleep
    systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
fi

function check_dmesg_ms9132()
{
        while true; do
                if [[ "$(dmesg | tail -n 10 | grep 'New USB device found, idVendor=345f, idProduct=9132' | wc -l)" != "0" ]]; then
                        echo "find dmesg error of ms9132";
                        killall evdi2ms9132;
                elif [[ "$(dmesg | tail -n 10 | grep 'New USB device found, idVendor=345f, idProduct=9133' | wc -l)" != "0" ]]; then
                        echo "find dmesg error of ms9132";
                        killall evdi2ms9132;
                else
                        sleep 1;
                fi
                sleep 5;
        done
}

function check_dmesg_fl2000()
{
        while true; do
                if [[ "$(dmesg | tail -n 10 | grep 'render_ctx?, render_ctx(0 free, 4 busy)' | wc -l)" != "0" ]]; then
                        echo "find dmesg error of fl2000";
                        killall evdi2fl2k;
                else
                        sleep 1;
                        # echo "not find dmesg error of fl2000";
                fi
                sleep 3
        done
}

function check_display_fl2000()
{
	if [ ! -f /etc/systemd/system/display-manager.service ]; then
                echo "not find display-manager service"
                if [ $is_kylinos -gt 1 ];then
                        while true; do
                        sleep 5
                                if [[ "$(ps aux | grep ${EVDI_HDMI_PWD}/evdi2fl2k | grep -v grep | wc -l)" != "0" ]] && [[ "$(systemctl is-active SophonHDMI)" != "active" ]]; then
                                        systemctl restart SophonHDMI
                                fi
                        done
                fi
		return
        fi
        systemctl restart display-manager
        while true; do
                sleep 5
                if [[ "$(ps aux | grep ${EVDI_HDMI_PWD}/evdi2fl2k | grep -v grep | wc -l)" != "0" ]] && [[ "$(systemctl is-active display-manager)" != "active" ]]; then
                        echo "restart display-manager"
                        systemctl restart display-manager;
                fi
        done
}

function check_display_ms9132()
{
        if [ ! -f /etc/systemd/system/display-manager.service ]; then
                echo "not find display-manager service"
                if [ $is_kylinos -gt 1 ];then
                        while true; do
                        sleep 5
                                if [[ "$(ps aux | grep evdi2ms9132 | grep -v grep | wc -l)" != "0" ]] && [[ "$(systemctl is-active SophonHDMI)" != "active" ]]; then
                                        systemctl restart SophonHDMI
                                fi
                        done
                fi
		return
	fi
	systemctl restart display-manager
        while true; do
                sleep 5
                if [[ "$(ps aux | grep evdi2ms9132 | grep -v grep | wc -l)" != "0" ]] && [[ "$(systemctl is-active display-manager)" != "active" ]]; then
                        echo "restart display-manager"
                        systemctl restart display-manager;
                fi
        done
}

function evdi2fl2k()
{
        while true; do
                status=$(find /sys -name "hdmi_status")
                if [[ "$status" != "" ]]; then
                        path1="$status/status"
                        if [[ -f "${path1}" ]]; then
                                if [[ "$(cat ${path1})" == "1" ]]; then
                                        echo "hdmi status 1 start evdi2fl2k"
                                        if [[ "$(cat /proc/device-tree/info/file-name)" == "bm1684x_se7_v3.0.dtb" ]] && [[ "$(lspci | grep uPD72020 | wc -l)" != "0" ]] ; then
                                                ${EVDI_HDMI_PWD}/evdi2fl2k 1280 720 60
                                        else
                                                ${EVDI_HDMI_PWD}/evdi2fl2k 1920 1080 60
                                        fi
                                elif [[ "$(cat ${path1})" == "0" ]]; then
                                        sleep 3
                                        # echo "hdmi status 0"
                                fi
                        else
                                echo "ERROR: cannot find hdmi_status/status of fl2000"
                        fi
                else
                        echo "ERROR: cannot find hdmi_status of fl2000"
                fi
                sleep 3
        done
}

function evdi2ms9132()
{
        pushd ${EVDI_HDMI_PWD}
        while true; do
        if [[ "$(lsusb | grep -i "345F:9132" | wc -l)" != "0" ]] && [[ "$(ps aux | grep -v grep |grep evdi2ms9132 | wc -l)" == "0"  ]]; then
            echo "have ms9132 start evdi2ms9132"
            ./evdi2ms9132 -r 0 -m 2
        elif [[ "$(lsusb | grep -i "345F:9133" | wc -l)" != "0" ]] && [[ "$(ps aux | grep -v grep |grep evdi2ms9132 | wc -l)" == "0"  ]]; then
            echo "have ms9132 start evdi2ms9132"
            ./evdi2ms9132 -r 0 -m 2
        elif [[ "$(lsusb | grep -i "345F:9132" | wc -l)" == "0" ]] && [[ "$(lsusb | grep -i "345F:9133" | wc -l)" == "0" ]]; then
            killall evdi2ms9132;
        fi
            sleep 2
        done
        popd
}

if [[ "${USB_HDMI_CHIP}" == "FL2000" ]]; then
    evdi2fl2k &
    sleep 20
    check_dmesg_fl2000 &
    check_display_fl2000 &
elif [[ "${USB_HDMI_CHIP}" == "MS9132" ]]; then
    export LD_LIBRARY_PATH=${EVDI_HDMI_PWD}:${LD_LIBRARY_PATH}
    evdi2ms9132 &
    sleep 20
    check_dmesg_ms9132 &
    check_display_ms9132 &
fi
exit 0
