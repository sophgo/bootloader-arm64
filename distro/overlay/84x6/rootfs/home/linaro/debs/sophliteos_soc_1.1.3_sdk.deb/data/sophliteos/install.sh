#!/bin/bash

set -e

case $(arch) in
  "x86_64")
    dir="linux_amd64"
    arch_type="amd64"
  ;;
  "aarch64")
    dir="linux_arm64"
    arch_type="arm64"
  ;;
  *)
  echo "unsupported arch"
  exit
  ;;
esac
if [[ -d "release/${dir}" ]]; then
  dir="release/${dir}/"
else
  dir=""
fi

if [[ -f /etc/systemd/system/sophliteos.service ]]; then
  systemctl stop sophliteos.service
  systemctl disable sophliteos.service
fi
mkdir -p /etc/sophliteos/config /var/log/sophliteos /var/lib/sophliteos/db /data/sophliteos
rm -rf /var/lib/sophliteos/dist

cp -r dist /var/lib/sophliteos/
cp "${dir}"sophliteos /bin
# 配置与 db 为每设备专属(含 ssm 地址、admin 密码等)，升级时保留已有文件，避免被开发模板覆盖
if [[ ! -f /etc/sophliteos/config/sophliteos.yaml ]]; then
  cp config/sophliteos.yaml /etc/sophliteos/config
fi
if [[ ! -f /var/lib/sophliteos/db/sophliteos.db ]]; then
  cp database/sophliteos.db /var/lib/sophliteos/db
fi
# 单板 SoC(SE5/SE7/SE9/84x2 等 aarch64 机型)的 bmssm 一定在本机,
# 若升级前遗留的 ssm.server 指向远端(如开发模板的 172.26.x:9779),
# 修正回 127.0.0.1:9779，否则 sophliteos 会读到远端主机而非本板算力。
if [[ "$arch_type" == "arm64" ]]; then
  awk '
    /^[[:space:]]*#/ { print; next }
    /^[^[:space:]]/ { in_ssm = ($0 ~ /^ssm:/); print; next }
    in_ssm && /^[[:space:]]+server:/ && $0 !~ /127\.0\.0\.1:9779/ {
      print "install.sh: 修正 ssm.server 为 127.0.0.1:9779" > "/dev/stderr"
      $0 = "  server: '\''127.0.0.1:9779'\''"
    }
    { print }
  ' /etc/sophliteos/config/sophliteos.yaml > /etc/sophliteos/config/sophliteos.yaml.new && \
    mv /etc/sophliteos/config/sophliteos.yaml.new /etc/sophliteos/config/sophliteos.yaml
fi
cp sophliteos.service /etc/systemd/system/
cp release_version.txt /var/lib/sophliteos

systemctl daemon-reload
systemctl enable sophliteos.service
systemctl start sophliteos.service