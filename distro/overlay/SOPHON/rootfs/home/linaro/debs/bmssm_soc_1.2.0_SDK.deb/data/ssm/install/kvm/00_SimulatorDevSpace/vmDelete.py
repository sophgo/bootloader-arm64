#!/usr/bin/python
import os
import sys
import time
import logging
import json

def vm_delete(vmName):
    str_status = os.popen("virsh list --all |grep %s"%vmName).read()
    if(str_status == ""):
        response["code"] = 1
        response["msg"] = "Domain not found: no domain with matching name %s"%vmName
        os.system("rm -rf /mnt/%s"%(sys.argv[1])) 
        logging.info(response)
        print(json.dumps(response))
        return(response)
        sys.exit(1)
    else:
        os.system("virsh shutdown %s"%vmName)
        fp = os.popen("virsh undefine %s"%vmName)
        undefine_status = fp.read()
        fp.close()
        domain_status = undefine_status.split('\n')
        if(domain_status[0] == "Domain %s has been undefined"%vmName):
            response["msg"] = "Domain %s delete successful"%vmName
            os.system("rm -rf /mnt/%s"%(sys.argv[1]))
        else:
            response["code"] = 1
            response["msg"] = "Domain %s delete failed,no response"%vmName
        logging.info("调用vm_delete方法查询结果：{}".format(response))
        time.sleep(10)
    print(json.dumps(response))
    return(response)
if __name__ == "__main__":
    os.popen("mkdir -p logs")
    response = {"code":0,"msg":""}
    logging.basicConfig(filename='logs/'+'delete.log',format='%(asctime)s %(levelname)s %(message)s',\
        datefmt='%Y-%m-%d %H:%M:%S',level=logging.INFO)
    logging.info('\r')
    logging.info("----------------start-----------------------------")
    logging.info("外部vm_delete.py调用记录：sys.argv:{}".format(sys.argv))
    if(len(sys.argv) <= 1):
        response["code"] = 1
        response["msg"] = "argv ERR"
        logging.info("调用vm_delete方法查询结果：{}".format(response))
        sys.exit(1)
    vmName = sys.argv[1]
    vm_delete(vmName)
    logging.info("----------------end-------------------------------")