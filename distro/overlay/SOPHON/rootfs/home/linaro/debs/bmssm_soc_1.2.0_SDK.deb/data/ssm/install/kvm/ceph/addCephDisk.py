import ceph
import sys
import json
import os
import ceph
import xml.etree.ElementTree as ET
import time
import logging

if __name__ == "__main__":
    response = {"code":1,"msg":""}
    os.popen("mkdir -p logs")
    logging.basicConfig(filename='logs/'+'add_disk.log',format='%(asctime)s %(levelname)s %(message)s',\
        datefmt='%Y-%m-%d %H:%M:%S',level=logging.INFO)
    logging.info('\r')
    logging.info("----------------start-----------------------------")
    
    
    #vm虚拟机存在判断
    vmName = sys.argv[1]
    if ceph.isVmExist(vmName) == False:
        response["code"] = 1
        response["msg"] = f"{vmName} not exist"
        print(json.dumps(response))
        logging.info(response)  
        sys.exit(1)
    logging.info(f"{vmName} exist") 
    
    images = json.loads(sys.argv[2])

    #加入的镜像是否在ceph中
    for image in images:
        cmd = f"rbd info {image}"
        output = os.popen(cmd).read()

        if "rbd image" not in output:
            response["code"] = 1
            response["msg"] = f"image {image} not exist in ceph"
            print(json.dumps(response))
            logging.info(response)  
            sys.exit(1)
    
    #加入的镜像是否在已经存在于虚拟机中        
    for image in images:
        if ceph.isImageInVm(vmName, image):
            response["code"] = 1
            response["msg"] = f"image {image}  exist in {vmName}"
            print(json.dumps(response))
            logging.info(response)  
            sys.exit(1)
    logging.info(f"{images} exist") 
    
    #虚拟机关机，200s超时
    if ceph.getVmStatus(vmName) != False:
        cmd = f"virsh shutdown {vmName}"
        os.system(cmd)
    for _ in range(20):
        if ceph.getVmStatus(vmName) != False:
            time.sleep(10)
        else:
            break
    
    if ceph.getVmStatus(vmName) != False:
        response["code"] = 1
        response["msg"] = f"{vmName} shutdown failed"
        print(json.dumps(response))
        logging.info(response)  
        sys.exit(1)
    logging.info(f"{vmName} shutdown successful") 
    
    id = ceph.secretVaild()
    ip, port = ceph.getCephIp()

    devs = ceph.getAllDev(vmName)

    #从vdb开始，寻找是否有可用的设备名，如vdc
    index = 'b'
    dev =  'vdb'
    diskXmls = []
    for image in images:
        while dev in devs:
            index = chr(ord(index) + 1)
            dev = "vd" + index
        devs.append(dev)
        print(dev)
        ceph.xmlDisk(image, id, dev, ip, port)
        tree = ET.parse("test.xml")
        diskXml = tree.getroot()
        diskXmls.append(diskXml)
        os.system("rm -f test.xml")
        
    ceph.addDiskXml(vmName, diskXmls)
    logging.info(f"{vmName} add {images} successful") 
    
    start_status = os.popen(f"virsh start {vmName}").read()
    logging.info("start_status:%s"%start_status)

    if(start_status[0:6] != "Domain"):
        logging.info(f"启动虚机报错，磁盘镜像")
        response["code"] = 1
        response["msg"] = f"Domain {vmName} start err，please check disk"
        print(json.dumps(response))
        logging.info(response)
        sys.exit(1)
    time.sleep(60)
    
    logging.info("----------------end-------------------------------")
    

    