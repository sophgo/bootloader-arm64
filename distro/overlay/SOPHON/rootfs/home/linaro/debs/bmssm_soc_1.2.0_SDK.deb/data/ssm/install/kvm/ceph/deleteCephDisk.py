import json
import os
import sys
import ceph
import time
import logging


if __name__ == "__main__":
    response = {"code":1,"msg":""}
    os.popen("mkdir -p logs")
    logging.basicConfig(filename='logs/'+'delete_disk.log',format='%(asctime)s %(levelname)s %(message)s',\
        datefmt='%Y-%m-%d %H:%M:%S',level=logging.INFO)
    logging.info('\r')
    logging.info("----------------start-----------------------------")
    
    #vm虚拟机存在判断
    vmName = sys.argv[1]
    if ceph.isVmExist(vmName) == False:
        response["code"] = 1
        response["msg"] = f"{vmName} not exist"
        print(json.dumps(response))
        sys.exit(1)
    logging.info(f"{vmName} exist") 
    
    #删除的镜像是否在虚拟机中
    images = json.loads(sys.argv[2])
    # print(images)
    devs = []
    
    for image in images:
        if image == "":
            continue
        dev = ceph.getDev(vmName, image)
        if dev != '':
            devs.append(dev)
    # print(devs)
           
    if (len(devs) == 0):
        response["code"] = 1
        response["msg"] = f"{images} not in {vmName}"
        print(json.dumps(response))
        sys.exit(1)
    logging.info(f"{images} exist") 
    
    #虚拟机关机，200s超时
    if ceph.getVmStatus(vmName) != False:
        cmd = f"virsh shutdown {vmName}"
        os.system(cmd)
    for _ in range(20):
        if ceph.getVmStatus(vmName) != False:
            time.sleep(10)
        else:
            break
    
    if ceph.getVmStatus(vmName) != False:
        response["code"] = 1
        response["msg"] = f"{vmName} shutdown failed"
        print(json.dumps(response))
        sys.exit(1)
    logging.info(f"{vmName} shutdown successful") 
    
    
    ceph.deleteCephDisk(vmName, devs)
    logging.info(f"{vmName} delete {images} successful") 
    
    start_status = os.popen(f"virsh start {vmName}").read()
    logging.info("start_status:%s"%start_status)

    if(start_status[0:6] != "Domain"):
        logging.info(f"启动虚机报错，磁盘镜像")
        response["code"] = 1
        response["msg"] = f"Domain {vmName} start err，please check disk"
        print(json.dumps(response))
        logging.info(response)
        sys.exit(1)
    time.sleep(60)
    
    logging.info("----------------end-------------------------------")