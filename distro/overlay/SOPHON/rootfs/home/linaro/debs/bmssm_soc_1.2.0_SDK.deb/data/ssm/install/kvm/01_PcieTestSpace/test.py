import createKvmTest
import sys

if __name__ == "__main__":
    chipstr = sys.argv[1]
    re = createKvmTest.HandleStr(chipstr)
    print(re)