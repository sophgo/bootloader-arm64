#!/bin/bash
export QT_QPA_PLATFORM_PLUGIN_PATH=/usr/lib/aarch64-linux-gnu/qt5/plugins
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib/aarch64-linux-gnu/qt5/lib
export QT_QPA_FB_DRM=1
export QT_QPA_PLATFORM=linuxfb:fb=/dev/dri/card0
export QT_QPA_EGLFS_KMS_CONNECTOR_INDEX=1
export SOPHON_QT_FONT_SIZE=15
# 定义状态文件路径
status_file="/sys/class/drm/card0-HDMI-A-1/status"

# 初始化 HDMI 状态为未知
hdmi_status="unknown"

# 无限循环，定期检查 HDMI 状态
systemctl stop getty@tty1.service
while true; do
    # 读取 HDMI 状态
    new_hdmi_status=$(cat "$status_file")
    # 如果 HDMI 状态变化，执行相应操作
    if [ "$new_hdmi_status" != "$hdmi_status" ]; then
        hdmi_status="$new_hdmi_status"
        if [ "$hdmi_status" = "connected" ]; then
	    if [ ! -n "$(lsof /dev/dri/card0|head -n 1)" ];then
            	# HDMI 连接状态为 "connected" (值为1)
            	echo "HDMI connected and card0 not in use. Starting SophUI."
            	# 启动 SophUI 应用
            	./SophUI 1>/dev/null 2>&1 & 
	    else 
		echo "HDMI connected.However card0 is in use,can't start SophUI"
	    fi
        else
		echo "HDMI disconnected. Stopping SophUI."
       		# 停止 SophUI 应用
            	pkill -f "SophUI"
        fi
    fi
    # 等待一段时间后再次检查 HDMI 状态
    sleep 1  # 1秒钟后检查
done
