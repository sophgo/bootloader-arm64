#!/bin/bash

# These parameters are used to exclude irrelevant files
# and directories in the context of repackaging mode.
# Users can add custom irrelevant files and directories
# in the format of ROOTFS_EXCLUDE_FLAGS_INT to the
# ROOTFS_EXCLUDE_FLAGS_USER parameter.
ROOTFS_EXCLUDE_FLAGS_INT='--exclude=./var/log/* --exclude=./boot/* --exclude=./recovery/* --exclude=./data/* --exclude=./media/* --exclude=./sys/* --exclude=./proc/* --exclude=./dev/* --exclude=./factory --exclude=./run/udev/* --exclude=./run/user/* --exclude=./socrepack'
ROOTFS_EXCLUDE_FLAGS_USER=''
ROOTFS_EXCLUDE_FLAGS_OPT="${ROOTFS_EXCLUDE_FLAGS_INT} ${ROOTFS_EXCLUDE_FLAGS_USER} --exclude=./opt/*"
ROOTFS_EXCLUDE_FLAGS_SYSTEM="${ROOTFS_EXCLUDE_FLAGS_INT} ${ROOTFS_EXCLUDE_FLAGS_USER} --exclude=./system/*"
ROOTFS_EXCLUDE_FLAGS=''
ROOTFS_INCLUDE_PATHS='./var/log/nginx '

# These parameters define several generated files and
# their default sizes for repackaging. Users can modify
# them according to their device specifications.
TGZ_FILES=(boot data opt system recovery rootfs)
# Here are the default sizes for each partition
declare -A TGZ_FILES_SIZE
TGZ_FILES_SIZE=(["boot"]=131072 ["recovery"]=3145728 ["rootfs"]=2621440 ["opt"]=2097152 ["system"]=2097152 ["data"]=4194304)
# The increased size of each partition compared to the original partition table
TGZ_ALL_SIZE=$((100*1024))
EMMC_ALL_SIZE=20971520
EMMC_MAX_SIZE=30000000
TAR_SIZE=0
TGZ_FILES_PATH=$(pwd)
PARTITION_FILE=partition32G.xml
SOC_VERSION=0
ONLY_TEST=0
NEED_BAK_FLASH=1
PWD="$(dirname "$(readlink -f "\$0")")"

if [ $PWD != "/socrepack" ]; then
    echo "The current path is not \"/socrepack\", please check it"
    exit
fi
echo "The current path is \"/socrepack\""

if [ -d "/system" ]; then
    SOC_VERSION=0
    TGZ_FILES=( ${TGZ_FILES[@]/opt} )
    unset TGZ_FILES_SIZE[opt]
    echo find /system dir, the version is 3.0.0 or lower, cannot suppot bakpack spi_flash
    ROOTFS_EXCLUDE_FLAGS="${ROOTFS_EXCLUDE_FLAGS_SYSTEM}"
	NEED_BAK_FLASH=0
elif [ -d "/opt" ]; then
    SOC_VERSION=1
    TGZ_FILES=( ${TGZ_FILES[@]/system} )
    unset TGZ_FILES_SIZE[system]
    echo find /opt dir, the version is V22.09.02 or higher
    ROOTFS_EXCLUDE_FLAGS="${ROOTFS_EXCLUDE_FLAGS_OPT}"
else
    echo cannot find /opt or /system, Please check the operating environment
    exit
fi

if [ "$NEED_BAK_FLASH" -eq 1 ]; then
    echo bakpack spi_flash start
	cp /boot/spi_flash.bin spi_flash.bin
    rm fip.bin
	SOC_NAME=""
	FLASH_OFFSET=0
	if [ -e /proc/device-tree/tsdma* ]; then
		echo soc is bm1684x
		SOC_NAME="bm1684x"
		FLASH_OFFSET=0
        flash_update -d fip.bin -b 0x6000000 -o 0x30000 -l 0x170000
	else
		echo soc is bm1684
		SOC_NAME="bm1684"
		FLASH_OFFSET=1
        flash_update -d fip.bin -b 0x6000000 -o 0x40000 -l 0x160000
	fi
	rm spi_flash_$SOC_NAME.bin
	flash_update -d spi_flash_$SOC_NAME.bin -b 0x6000000 -o 0 -l 0x200000
	dd if=spi_flash_$SOC_NAME.bin of=spi_flash.bin seek=$FLASH_OFFSET bs=4194304 conv=notrunc
	cp spi_flash.bin /boot/spi_flash.bin.socBakNew
	echo bakpack spi_flash end
fi

for TGZ_FILE in "${TGZ_FILES[@]}"
do
    case $TGZ_FILE in
        "rootfs")
            pushd /
            echo tar $TGZ_FILE flags : $ROOTFS_EXCLUDE_FLAGS ...
            if [ "$ONLY_TEST" == "0" ]; then
                mkdir -p /etc/systemd/system/basic.target.wants/
                pushd /etc/systemd/system/basic.target.wants/
                ln -s ../../../../lib/systemd/system/resize-helper.service
                popd
				rm -rf $TGZ_FILES_PATH/$TGZ_FILE.tar
                tar -caSf $TGZ_FILES_PATH/$TGZ_FILE.tar $ROOTFS_EXCLUDE_FLAGS ./*
				tar -raSf $TGZ_FILES_PATH/$TGZ_FILE.tar $ROOTFS_INCLUDE_PATHS
				gzip -c $TGZ_FILES_PATH/$TGZ_FILE.tar > $TGZ_FILES_PATH/$TGZ_FILE.tgz
				rm -rf $TGZ_FILES_PATH/$TGZ_FILE.tar
                rm /etc/systemd/system/basic.target.wants/resize-helper.service
            fi
            TAR_SIZE=$(du -s ./ $ROOTFS_EXCLUDE_FLAGS | awk '{s=$1} END {printf "%d", s}')
            TAR_SIZE=$(($TAR_SIZE+$((512*1024))))
            popd
            ;;
        *)
            pushd /$TGZ_FILE
            echo tar $TGZ_FILE ...
            if [ "$ONLY_TEST" == "0" ]; then
                tar -caSf $TGZ_FILES_PATH/$TGZ_FILE.tgz ./*
            fi
            TAR_SIZE=$(du -s ./ | awk '{s=$1} END {printf "%d", s}')
            TAR_SIZE=$(($TAR_SIZE+$((100*1024))))
            popd
            ;;
    esac
    echo $TGZ_FILES_PATH/$TGZ_FILE.tgz : $TAR_SIZE KB
    if [ $TAR_SIZE -gt ${TGZ_FILES_SIZE["$TGZ_FILE"]} ];
    then
        echo need to expand $TGZ_FILE from ${TGZ_FILES_SIZE[$TGZ_FILE]} KB to $TAR_SIZE KB
        TGZ_FILES_SIZE[$TGZ_FILE]=$TAR_SIZE
    fi
done

for TGZ_FILE in "${TGZ_FILES[@]}"
do
    TGZ_ALL_SIZE=$(($TGZ_ALL_SIZE+${TGZ_FILES_SIZE["$TGZ_FILE"]}))
done
echo partition table size : $TGZ_ALL_SIZE KB

if [ $TGZ_ALL_SIZE -gt $EMMC_ALL_SIZE ];
    then
        echo need to expand default partition table size from $EMMC_ALL_SIZE KB to $TGZ_ALL_SIZE KB
        EMMC_ALL_SIZE=$TGZ_ALL_SIZE
fi

# if [ $TGZ_ALL_SIZE -gt $EMMC_MAX_SIZE ];
#     then
#         echo The total size is too large.
#         exit 1
# fi

echo The generated file partition32G.xml can replace file bootloader-arm64/scripts/partition32G.xml in VXX
echo or replace some information for 3.0.0
echo "<physical_partition size_in_kb=\"$EMMC_ALL_SIZE\">" > $TGZ_FILES_PATH/$PARTITION_FILE
echo " 	<partition label=\"BOOT\"       size_in_kb=\"${TGZ_FILES_SIZE[boot]}\"  readonly=\"false\"  format=\"1\" />" >> $TGZ_FILES_PATH/$PARTITION_FILE
echo " 	<partition label=\"RECOVERY\"   size_in_kb=\"${TGZ_FILES_SIZE[recovery]}\"  readonly=\"false\" format=\"2\" />" >> $TGZ_FILES_PATH/$PARTITION_FILE
echo " 	<partition label=\"MISC\"       size_in_kb=\"10240\"  readonly=\"false\"   format=\"0\" />" >> $TGZ_FILES_PATH/$PARTITION_FILE
echo " 	<partition label=\"ROOTFS\"     size_in_kb=\"${TGZ_FILES_SIZE[rootfs]}\" readonly=\"true\"   format=\"2\" />" >> $TGZ_FILES_PATH/$PARTITION_FILE
echo " 	<partition label=\"ROOTFS_RW\"  size_in_kb=\"6291456\" readonly=\"false\"  format=\"2\" />" >> $TGZ_FILES_PATH/$PARTITION_FILE
if [ "$SOC_VERSION" == "1" ]; then
    echo " 	<partition label=\"OPT\"        size_in_kb=\"${TGZ_FILES_SIZE[opt]}\" readonly=\"false\"  format=\"2\" />" >> $TGZ_FILES_PATH/$PARTITION_FILE
else
    echo " 	<partition label=\"SYSTEM\"     size_in_kb=\"${TGZ_FILES_SIZE[system]}\" readonly=\"false\"  format=\"2\" />" >> $TGZ_FILES_PATH/$PARTITION_FILE
fi
echo " 	<partition label=\"DATA\"       size_in_kb=\"${TGZ_FILES_SIZE[data]}\" readonly=\"false\"  format=\"2\" />" >> $TGZ_FILES_PATH/$PARTITION_FILE
echo "</physical_partition>" >> $TGZ_FILES_PATH/$PARTITION_FILE
cat $TGZ_FILES_PATH/$PARTITION_FILE
sync