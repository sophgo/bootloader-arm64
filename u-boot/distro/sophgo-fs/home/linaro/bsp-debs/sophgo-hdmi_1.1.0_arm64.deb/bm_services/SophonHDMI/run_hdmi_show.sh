#!/bin/sh -x
fl2000=$(lsmod | grep fl2000 | awk '{print $1}')

echo $fl2000
if [ "$fl2000" != "fl2000" ]; then
	echo "insmod fl2000"
else
	echo "fl2000 already insmod"
fi

export PATH=$PATH:/opt/bin:/bm_bin
#export SOPHON_QT_BG_PATH=sample.png # 配置自定义背景
export QTDIR=/usr/lib/aarch64-linux-gnu #qtsdk在系统上的路径
export QT_QPA_FONTDIR=$QTDIR/fonts 
export QT_QPA_PLATFORM_PLUGIN_PATH=$QTDIR/qt5/plugins/ 
export LD_LIBRARY_PATH=/opt/lib:$LD_LIBRARY_PATH 
export QT_QPA_PLATFORM=linuxfb:fb=/dev/fl2000-0 #framebuffer驱动
export SOPHON_QT_FONT_SIZE=70 #使用该环境变量配置程序默认字体大小
SophUI_path=/bm_services/SophonHDMI/
SophUIDEMO_path=${SophUI_path}/SophUIDEMO.sh 
while true; do
        rm -f $SophUIDEMO_path
        ${SophUI_path}/SophUI
        ret=$?
        if [ $ret -ne 0 ]; then
        echo "SophUI exited with error code: $ret"
        exit $ret
    fi
        if [ -e "$SophUIDEMO_path" ]; then
                chmod +x $SophUIDEMO_path
                bash -x $SophUIDEMO_path
                        ret=$?
                        if [ $ret -ne 0 ]; then
                                echo "SophUIDEMO exited with error code: $ret"
                                exit $ret
                        fi
        else
                echo "File does not exist: $SophUIDEMO_path"
        fi
done
